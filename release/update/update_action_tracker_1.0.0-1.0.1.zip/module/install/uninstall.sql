DROP TABLE IF EXISTS `action_tracker_connection`;
DROP TABLE IF EXISTS `action_tracker_log`;