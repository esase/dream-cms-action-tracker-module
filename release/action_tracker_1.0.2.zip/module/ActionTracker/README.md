# Action tracker
Action tracker module for Dream CMS. Module allows to track all site changes.
