<?php 

return [
	'module_path' => 'module/ActionTracker',
    'layout_path' => 'layout/actiontracker'
];
